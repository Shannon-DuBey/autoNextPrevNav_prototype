# autoNextPrevNav_prototype
Auto generate href links based on file names in a folder

JS creates href links for Next/Previous buttons.
Requires files be in same folder and names as follows

First page: landingPage.html
last page: LastPage.html
All other pages take form of page*.html

Infinite number of files between first and last pages, currently set to allow 98 but easily adjusted in the JS to go higher
